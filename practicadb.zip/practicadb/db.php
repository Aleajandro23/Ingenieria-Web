<?php
$servername = "localhost";  // Cambia esto por el nombre de tu servidor
$username = "root";         // Tu nombre de usuario de MySQL
$password = "";             // Tu contraseña de MySQL
$dbname = "db_ruben";  // El nombre de la base de datos a la que deseas conectarte

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
} 

?>
