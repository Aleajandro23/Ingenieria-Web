<?php
include 'db.php'; // Incluir la conexión a la base de datos

// Verificar si se pasa un ID a través de la URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Consulta para obtener la categoría específica por ID
    $sql = "SELECT * FROM Categoria WHERE id = ?";
    
    // Preparar la consulta para evitar SQL injection
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id); // "i" indica que el parámetro es un entero
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Si se encuentra la categoría, mostrar los datos en el formulario
        if ($result->num_rows > 0) {
            $categoria = $result->fetch_assoc();
        } else {
            echo "Categoría no encontrada.";
            exit;
        }
    } else {
        echo "Error en la consulta: " . $conn->error;
        exit;
    }
} else {
    echo "No se ha proporcionado un ID.";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Categoría</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Editar Categoría</h1>
    
    <!-- Formulario para editar los datos de la categoría -->
    <form action="procesar.php" method="POST">
        <!-- Acción 'actualizar' para que 'procesar.php' sepa qué hacer -->
        <input type="hidden" name="accion" value="actualizar">
        
        <!-- ID de la categoría para saber qué categoría actualizar -->
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($categoria['id']); ?>">
        
        <!-- Campo de Nombre -->
        <label for="nombre">Nombre de la Categoría:</label>
        <input type="text" name="nombre" value="<?php echo htmlspecialchars($categoria['nombre']); ?>" required>

        <!-- Campo de Descripción -->
        <label for="descripcion">Descripción:</label>
        <textarea name="descripcion" required><?php echo htmlspecialchars($categoria['descripcion']); ?></textarea>

        <!-- Campo de Código de Categoría -->
        <label for="codigodecategoria">Código de Categoría:</label>
        <input type="text" name="codigodecategoria" value="<?php echo htmlspecialchars($categoria['codigodecategoria']); ?>" required>

        <!-- Campo de Estado -->
        <label for="estado">Estado:</label>
        <select name="estado" required>
            <option value="activo" <?php echo ($categoria['estado'] == 'activo' ? 'selected' : ''); ?>>Activo</option>
            <option value="inactivo" <?php echo ($categoria['estado'] == 'inactivo' ? 'selected' : ''); ?>>Inactivo</option>
        </select>

        <!-- Botón para enviar el formulario -->
        <button type="submit">Actualizar Categoría</button>
    </form>
    
    <!-- Enlace para volver a la página principal -->
    <a href="index.php" class="btn">Volver a la página principal</a>
</body>
</html>
