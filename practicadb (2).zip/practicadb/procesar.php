<?php
include 'db.php'; // Conexión a la base de datos

if (isset($_POST['accion'])) {
    $accion = $_POST['accion'];
    $id = $_POST['id'] ?? null;  // ID de la categoría (necesario para actualizar o eliminar)
    $nombre = $_POST['nombre'] ?? '';  // Nombre de la categoría
    $descripcion = $_POST['descripcion'] ?? '';  // Descripción de la categoría
    $codigodecategoria = $_POST['codigodecategoria'] ?? '';  // Código de la categoría
    $fechaDeCreacion = $_POST['fechaDeCreacion'] ?? null;  // Fecha de creación (solo para creación)
    $estado = $_POST['estado'] ?? '';  // Estado de la categoría (Activo/Inactivo)

    if ($accion === 'crear') {
        // Consulta preparada para evitar inyección de SQL
        $sql = "INSERT INTO Categoria (nombre, descripcion, codigodecategoria, fechaDeCreacion, estado)
                VALUES (?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sssss", $nombre, $descripcion, $codigodecategoria, $fechaDeCreacion, $estado);
            if ($stmt->execute()) {
                // Redirigir a la página principal después de la acción
                header("Location: index.php");
                exit();
            } else {
                echo "Error al crear la categoría: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error en la preparación de la consulta: " . $conn->error;
        }
    } elseif ($accion === 'actualizar' && $id) {
        // Consulta preparada para evitar inyección de SQL
        $sql = "UPDATE Categoria 
                SET nombre = ?, descripcion = ?, codigodecategoria = ?, 
                    fechaDeCreacion = ?, estado = ? 
                WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sssssi", $nombre, $descripcion, $codigodecategoria, $fechaDeCreacion, $estado, $id);
            if ($stmt->execute()) {
                // Redirigir a la página principal después de la acción
                header("Location: index.php");
                exit();
            } else {
                echo "Error al actualizar la categoría: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error en la preparación de la consulta: " . $conn->error;
        }
    } elseif ($accion === 'eliminar' && $id) {
        // Consulta preparada para evitar inyección de SQL
        $sql = "DELETE FROM Categoria WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                // Redirigir a la página principal después de la acción
                header("Location: index.php");
                exit();
            } else {
                echo "Error al eliminar la categoría: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error en la preparación de la consulta: " . $conn->error;
        }
    } else {
        echo "Acción no válida o ID no proporcionado.";
    }
}

$conn->close(); // Cerrar la conexión a la base de datos
?>
