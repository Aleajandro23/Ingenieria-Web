<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Categorías</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Gestión de Categorías</h1>

    <!-- Botones de acción -->
    <div class="botones-acciones">
        <a href="crear.php" class="btn crear">Crear Nueva Categoría</a>
        <!-- Botón para Editar Categoría -->
        <a href="editar.php" class="btn btn-editar-categoria">Editar Categoría</a>
    </div>

    <!-- Tabla de Categorías -->
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Código de Categoría</th>
                <th>Fecha de Creación</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Conexión a la base de datos
            include 'db.php'; 
            
            // Consulta para obtener todas las categorías
            $sql = "SELECT * FROM Categoria";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Si hay resultados, mostrar las categorías
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['descripcion']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['codigodecategoria']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['fechaDeCreacion']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['estado']) . "</td>";
                    echo "<td class='acciones'>";  // Agrupamos los botones de acciones
                    // Botón de Editar
                    echo "<a href='editar.php?id={$row['id']}' class='btn editar'>Editar</a>";
                    // Formulario para eliminar la categoría
                    echo "<form action='procesar.php' method='POST' style='display:inline;'>
                            <input type='hidden' name='id' value='{$row['id']}'>
                            <input type='hidden' name='accion' value='eliminar'>
                            <button type='submit' class='btn eliminar'>Eliminar</button>
                          </form>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                // Si no hay categorías
                echo "<tr><td colspan='6'>No hay categorías registradas</td></tr>";
            }
            
            $conn->close(); // Cerrar la conexión
            ?>
        </tbody>
    </table>
</body>
</html>
