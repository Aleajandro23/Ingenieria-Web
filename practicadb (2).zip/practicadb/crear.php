<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Nueva Categoría</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Crear Nueva Categoría</h1>
    
    <!-- Formulario para crear una nueva categoría -->
    <form action="procesar.php" method="POST">
        <input type="hidden" name="accion" value="crear">
        
        <label for="nombre">Nombre de la Categoría:</label>
        <input type="text" name="nombre" required>
        
        <label for="descripcion">Descripción:</label>
        <textarea name="descripcion"></textarea>
        
        <label for="codigodecategoria">Código de Categoría:</label>
        <input type="text" name="codigodecategoria" required>
        
        <label for="fechaDeCreacion">Fecha de Creación:</label>
        <input type="date" name="fechaDeCreacion" value="<?php echo date('Y-m-d'); ?>" readonly>
        
        <label for="estado">Estado:</label>
        <select name="estado">
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
        </select>
        
        <button type="submit">Añadir Categoría</button>
    </form>
    
    <a href="index.php" class="btn">Volver a la página principal</a>
</body>
</html>
