<?php
include 'db.php'; // Asegúrate de que este archivo contiene la conexión a la base de datos

// Consulta para obtener todas las categorías
$sql = "SELECT * FROM Categoria";
$result = $conn->query($sql);

// Verificamos si hay resultados
if ($result->num_rows > 0) {
    // Mostrar cada fila de resultados
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
        echo "<td>" . htmlspecialchars($row['descripcion']) . "</td>";
        echo "<td>" . htmlspecialchars($row['codigodecategoria']) . "</td>";
        echo "<td>" . htmlspecialchars($row['fechaDeCreacion']) . "</td>";
        echo "<td>" . htmlspecialchars($row['estado']) . "</td>";
        echo "<td>";
        // Enlace para editar
        echo "<a href='editar.php?id={$row['id']}' class='btn'>Editar</a>";
        
        // Formulario para eliminar
        echo "<form action='procesar.php' method='POST' style='display:inline;'>
                <input type='hidden' name='id' value='{$row['id']}'>
                <input type='hidden' name='accion' value='eliminar'>
                <button type='submit' class='btn eliminar'>Eliminar</button>
              </form>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    // Si no hay categorías registradas
    echo "<tr><td colspan='6'>No hay categorías registradas</td></tr>";
}

// Cerrar la conexión
$conn->close();
?>
